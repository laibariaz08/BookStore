using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookStore.Views.Dashboard
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
