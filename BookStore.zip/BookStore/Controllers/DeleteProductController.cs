﻿//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using BookStore.Models;

//namespace BookStore.Controllers
//{
//    [Authorize(Policy = "AdminAccess")]
//    [Authorize(Policy = "RequireAuthenticatedUser")]
//    public class DeleteProductController : Controller
//    {
//        [HttpGet]
//        public ActionResult DeleteProduct()
//        {
//            return View();
//        }
//        [HttpPost]
//        public ActionResult DeleteProduct(int ID)
//        {
//            string connectionString = "Server=(localdb)\\mssqllocaldb;Database=CheckDB;Trusted_Connection=True;MultipleActiveResultSets=true";
//            GenericRepository<Product> repo = new GenericRepository<Product>(connectionString);
//            repo.Delete(ID);
//            return View();
//        }
//    }
//}
