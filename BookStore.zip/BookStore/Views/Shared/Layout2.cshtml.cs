using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.Shared
{
    public class Layout2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
