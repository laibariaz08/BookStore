using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.UpdateProduct
{
    public class UpdateProductModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
