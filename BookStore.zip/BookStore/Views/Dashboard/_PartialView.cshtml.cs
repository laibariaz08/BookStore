using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.Dashboard
{
    public class _PartialViewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
