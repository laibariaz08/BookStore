using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.DeleteCategory
{
    public class DeleteCategoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
