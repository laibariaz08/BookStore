using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookStore.Views.Dashboard
{
    public class DetailProductModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
