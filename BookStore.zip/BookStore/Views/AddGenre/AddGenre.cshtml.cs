using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.AddCategory
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
