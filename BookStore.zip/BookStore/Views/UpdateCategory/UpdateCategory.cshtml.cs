using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.UpdateCategory
{
    public class UpdateCategoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
