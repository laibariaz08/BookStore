﻿//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using BookStore.Models;

//namespace BookStore.Controllers
//{
//    [Authorize(Policy = "AdminAccess")]
//    [Authorize(Policy = "RequireAuthenticatedUser")]
//    public class UpdateProductController : Controller
//    {
//        [HttpGet]
//        public ActionResult UpdateProduct()
//        {
//            return View();
//        }
//        [HttpPost]
//        public ActionResult UpdateProduct(string Name, int Price, int Stock)
//        {
//            string connectionString = "Server=(localdb)\\mssqllocaldb;Database=CheckDB;Trusted_Connection=True;MultipleActiveResultSets=true";
//            Product product = new Product();
//            product.name = Name;
//            product.Price = Price;
//            product.stock = Stock;
//            GenericRepository<Product> repo = new GenericRepository<Product>(connectionString);
//            repo.Update(product);
//            //Productrepository repository = new Productrepository();
//            //repository.Add(product);
//            return View();
//        }
//    }
//}
