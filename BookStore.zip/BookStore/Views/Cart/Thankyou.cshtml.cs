using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Cart
{
    public class ThankyouModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
