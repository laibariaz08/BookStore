using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Cart
{
    public class CartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
