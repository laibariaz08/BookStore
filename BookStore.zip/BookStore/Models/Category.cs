﻿namespace BookStore.Models
{
    public class Category
    {
		private int ID;

		public int id
		{
			get { return ID; }
			set { ID = value; }
		}
		private string Name;

		public string name
		{
			get { return Name; }
			set { Name = value; }
		}


	}
}
