﻿namespace BookStore.Models
{
    public class BookGenre
    {
        public List<Books> books=new List<Books>();
        public List<Genres> genres=new List<Genres>();
    }
}
