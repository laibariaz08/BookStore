using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Views.DeleteProduct
{
    public class DeleteProductModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
